import csv
from sklearn.ensemble import RandomForestClassifier
import matplotlib.pyplot as mat

csvfile = open(r"C:\Users\User\Desktop\school\2nd\DataMining\A\test_data.csv")
testfile = list(csv.reader(csvfile))
csvfile.close()

csvfile = open(r"C:\Users\User\Desktop\school\2nd\DataMining\A\train_data.csv")
trainfile = list(csv.reader(csvfile))
csvfile.close()

csvfile = open(r"C:\Users\User\Desktop\school\2nd\DataMining\B\test_data.csv")
test2 = list(csv.reader(csvfile))
csvfile.close()

csvfile = open(r"C:\Users\User\Desktop\school\2nd\DataMining\B\train_data.csv")
train2 = list(csv.reader(csvfile))
csvfile.close()

x_train = [i[:-1] for i in trainfile[1:]]
x_test = [i[:-1] for i in testfile[1:]]
y_train = [i[-1] for i in trainfile[1:]]
y_test = [[i[-1]] for i in testfile[1:]]

#2nd train

x_train2 =  [i[:-1] for i in train2[1:]]
x_test2 =  [i[:-1] for i in test2[1:]]
y_train2 = [i[-1] for i in train2[1:]]
y_test2 = [i[-1] for i in test2[1:]]

randomForestModel = RandomForestClassifier(n_estimators=100)
randomForestModel.fit(x_train2, y_train2)
predict = randomForestModel.predict(x_train2)

print("Accuracy in A:")
print("Test: ", randomForestModel.score(x_train2, y_train2))
print("Train: ", randomForestModel.score(x_test2, y_test2))

features = list(train2[0][:-1])
impt = randomForestModel.feature_importances_
impt, features= zip(*sorted(zip(impt,features)))



#2nd train

randomForestModel = RandomForestClassifier(n_estimators=100)
randomForestModel.fit(x_train2, y_train2)
predict = randomForestModel.predict(x_train2)

print("Accuracy in B:")
print("Test: ", randomForestModel.score(x_train2, y_train2))
print("Train: ", randomForestModel.score(x_test2, y_test2))

features2 = list(train2[0][:-1])
impt2 = randomForestModel.feature_importances_
impt2, features2= zip(*sorted(zip(impt2,features2)))

mat.subplot(2,1,1)
mat.barh(range(len(features)),impt)
mat.yticks(range(len(features)),features)
mat.title('Importance of Each Feature')

mat.subplot(2,1,2)
mat.barh(range(len(features2)),impt)
mat.yticks(range(len(features2)),features2)
mat.show()